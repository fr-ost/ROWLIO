function e(e) {
	return typeof e == "object" && !!e && e.rowlio === 1 && typeof e.internal == "string";
}
// src/background/index.ts
var t = "app.html";
async function n() {
	let e = chrome.runtime.getURL(t), n = (await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.TAB] })).find((t) => t.tabId >= 0 && typeof t.documentUrl == "string" && t.documentUrl.startsWith(e));
	return n ? {
		tabId: n.tabId,
		windowId: n.windowId
	} : null;
}
async function r(e) {
	let r = e.intent.kind !== "picker", i = await n();
	if (i) {
		let t = {
			rowlio: 1,
			internal: "bind-workspace",
			...e
		};
		try {
			await chrome.runtime.sendMessage(t), r && (await chrome.tabs.update(i.tabId, { active: !0 }), await chrome.windows.update(i.windowId, { focused: !0 }));
			return;
		} catch {}
	}
	let a = new URLSearchParams({
		tab: String(e.tabId),
		url: e.url,
		title: e.title,
		intent: JSON.stringify(e.intent)
	}), o;
	try {
		o = (await chrome.tabs.get(e.tabId)).index + 1;
	} catch {
		o = void 0;
	}
	await chrome.tabs.create({
		url: `${chrome.runtime.getURL(t)}?${a.toString()}`,
		active: r,
		openerTabId: e.tabId,
		index: o
	});
}
chrome.runtime.onInstalled.addListener((e) => {
	e.reason === chrome.runtime.OnInstalledReason.INSTALL && chrome.tabs.create({ url: chrome.runtime.getURL(`${t}#/`) });
}), chrome.commands.onCommand.addListener((e, t) => {
	if (!t || t.id === void 0) return;
	let n = {
		tabId: t.id,
		url: t.url ?? "",
		title: t.title ?? ""
	};
	e === "open-workspace" && r({
		...n,
		intent: { kind: "none" }
	}), e === "start-picker" && r({
		...n,
		intent: { kind: "picker" }
	});
}), chrome.runtime.onMessage.addListener((t, n, i) => {
	if (n.id !== chrome.runtime.id || n.tab && !n.url?.startsWith(chrome.runtime.getURL("")) || !e(t) || t.internal !== "open-workspace") return !1;
	let a = t;
	return typeof a.tabId != "number" || typeof a.url != "string" || typeof a.title != "string" ? !1 : (r({
		tabId: a.tabId,
		url: a.url,
		title: a.title,
		intent: a.intent
	}).then(() => i({ ok: !0 }), (e) => i({
		ok: !1,
		error: e instanceof Error ? e.message : String(e)
	})), !0);
});
